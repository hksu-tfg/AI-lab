// 在「頁面主世界」執行：
// 1) 攔截系統送出的請求 → 取得 session_key / stdSemeId / itemId
// 2) 攔截成績 API 的「回應」→ 直接拿到成績資料 dataRows
(function () {
  "use strict";

  // 各科成績端點（含 orderS 班排、scorePg2 PR）。
  // 用 ".action" 結尾比對，才不會誤抓到 ...selectA0410s.action
  var SCORE_PART = "OpenItemScoreView_select.action";
  // 總排名/總平均端點（整學期加總：scoreT 總分、orderG/pnmG 全年級排名…）
  var STAT_PART = "ItemScoreStat_select.action";

  function classify(url) {
    if (!url) return null;
    if (url.indexOf(SCORE_PART) !== -1) return "score";
    if (url.indexOf(STAT_PART) !== -1) return "stat";
    return null;
  }

  // 從送出的 body 取出憑證
  function captureReq(body) {
    if (typeof body !== "string" || body.indexOf("=") === -1) return;
    try {
      var params = new URLSearchParams(body);
      var data = {};
      if (params.has("session_key")) data.session_key = params.get("session_key");
      if (params.has("stdSemeId")) data.stdSemeId = params.get("stdSemeId");
      if (params.has("itemId")) data.itemId = params.get("itemId");
      if (Object.keys(data).length) {
        window.postMessage({ __scoreHelper: true, type: "capture", data: data }, "*");
      }
    } catch (e) {}
  }

  // 從成績 / 統計 API 的回應取出 dataRows
  function captureRes(url, text) {
    var type = classify(url);
    if (!type || !text) return;
    try {
      var json = JSON.parse(text);
      var rows = json.dataRows || json.rows || [];
      if (rows && rows.length) {
        window.postMessage({ __scoreHelper: true, type: type, rows: rows }, "*");
      }
    } catch (e) {}
  }

  // --- XMLHttpRequest ---
  var origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url) {
    this.__shUrl = url;
    return origOpen.apply(this, arguments);
  };

  var origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (body) {
    var xhr = this;
    try { captureReq(body); } catch (e) {}
    this.addEventListener("load", function () {
      try { captureRes(xhr.__shUrl, xhr.responseText); } catch (e) {}
    });
    return origSend.apply(this, arguments);
  };

  // --- fetch（備援） ---
  if (typeof window.fetch === "function") {
    var origFetch = window.fetch;
    window.fetch = function (input, init) {
      try { if (init && typeof init.body === "string") captureReq(init.body); } catch (e) {}
      var url = typeof input === "string" ? input : input && input.url;
      return origFetch.apply(this, arguments).then(function (resp) {
        try {
          if (classify(url)) {
            resp.clone().text().then(function (t) { captureRes(url, t); }).catch(function () {});
          }
        } catch (e) {}
        return resp;
      });
    };
  }
})();
