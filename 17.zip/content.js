// 在「隔離世界」執行：
// 1) 接收 inject.js 攔到的憑證與成績/統計，存進 chrome.storage
// 2) 收到 popup 的查詢請求時，以頁面同源身分去打 API（自動帶 cookie）

const SCORE_URL = "https://sschool.tp.edu.tw/A0410S_OpenItemScoreView_select.action"; // 各科
const STAT_URL = "https://sschool.tp.edu.tw/A0410S_ItemScoreStat_select.action";      // 總排名

// 擴充功能是否仍有效（重新載入後，舊的 content script 會失效 → 避免噴錯）
function alive() {
  try {
    return !!(chrome.runtime && chrome.runtime.id);
  } catch (e) {
    return false;
  }
}

window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  const msg = event.data;
  if (!msg || msg.__scoreHelper !== true) return;
  if (!alive()) return; // 失效的舊腳本：靜默跳過，請重新整理頁面

  try {
    if (msg.type === "capture") {
      chrome.storage.local.get(["creds"], (res) => {
        if (!alive()) return;
        const creds = res.creds || {};
        Object.assign(creds, msg.data);
        creds.updatedAt = Date.now();
        chrome.storage.local.set({ creds });
      });
    }

    // 各科成績
    if (msg.type === "score") {
      chrome.storage.local.set({ lastScore: { rows: msg.rows, at: Date.now() } });
    }

    // 總排名/總平均
    if (msg.type === "stat") {
      chrome.storage.local.set({ lastStat: { rows: msg.rows, at: Date.now() } });
    }
  } catch (e) {
    /* Extension context invalidated：請 F5 重新整理頁面 */
  }
});

// 處理 popup 的「重新查詢」：一次打兩支
chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (req && req.action === "queryAll") {
    queryAll(req)
      .then(sendResponse)
      .catch((err) => sendResponse({ ok: false, error: String((err && err.message) || err) }));
    return true;
  }
});

async function queryAll(creds) {
  // 各科必查；總排名查不到不致命（有些考試可能沒這支）
  const scoreRows = await fetchRows(SCORE_URL, creds);
  let statRows = [];
  try {
    statRows = await fetchRows(STAT_URL, creds);
  } catch (e) {
    /* 總排名失敗就略過，仍回各科 */
  }
  return { ok: true, scoreRows, statRows };
}

async function fetchRows(baseUrl, { itemId, stdSemeId, session_key }) {
  if (!itemId) throw new Error("尚未攔到任何段考。請先在系統內點開一次段考成績。");
  if (!stdSemeId) throw new Error("缺少學期資訊，請先在系統內操作一次。");
  if (!session_key) throw new Error("缺少憑證，請先在系統內操作一次。");

  const url =
    baseUrl +
    "?itemId=" + encodeURIComponent(itemId) +
    "&stdSemeId=" + encodeURIComponent(stdSemeId);

  const body = new URLSearchParams({
    itemId: String(itemId),
    stdSemeId: String(stdSemeId),
    _search: "false",
    nd: String(Date.now()),
    rows: "-1",
    page: "1",
    sidx: "",
    sord: "asc",
    session_key: session_key,
  });

  const resp = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
    body: body.toString(),
    credentials: "include",
  });
  if (!resp.ok) throw new Error("HTTP " + resp.status + "（可能未登入或 token 過期）");

  const json = await resp.json();
  return json.dataRows || json.rows || [];
}
