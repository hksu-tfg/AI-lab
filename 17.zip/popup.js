const SYSTEM_URL_MATCH = "https://sschool.tp.edu.tw/*";
const $ = (id) => document.getElementById(id);

document.addEventListener("DOMContentLoaded", init);

async function init() {
  await refreshView();
  $("refreshBtn").addEventListener("click", onRefresh);
}

async function refreshView() {
  const { creds, lastScore, lastStat } = await chrome.storage.local.get([
    "creds",
    "lastScore",
    "lastStat",
  ]);
  renderStatus(creds, lastScore);

  const hasScore = lastScore && lastScore.rows && lastScore.rows.length;
  const hasStat = lastStat && lastStat.rows && lastStat.rows.length;

  if (hasScore || hasStat) {
    let html = "";
    if (hasStat) html += renderStat(lastStat.rows[0]);
    if (hasScore) html += renderRows(lastScore.rows);
    $("result").innerHTML = html;
    $("hint").style.display = "none";
  } else {
    $("result").innerHTML = "";
    $("hint").style.display = "block";
  }
}

function renderStatus(creds, lastScore) {
  const ok = creds && creds.session_key;
  const el = $("status");
  let html = ok
    ? `<span class="dot ok"></span><span class="ok">已擷取憑證</span>`
    : `<span class="dot bad"></span><span class="bad">尚未擷取憑證</span>`;
  if (lastScore && lastScore.at) {
    html += `<span class="age">更新於 ${fmtAgo(lastScore.at)}</span>`;
  }
  el.innerHTML = html;
}

function fmtAgo(at) {
  const s = Math.round((Date.now() - at) / 1000);
  if (s < 60) return `${s} 秒前`;
  if (s < 3600) return `${Math.round(s / 60)} 分鐘前`;
  return `${Math.round(s / 3600)} 小時前`;
}

async function getSystemTab() {
  const tabs = await chrome.tabs.query({ url: SYSTEM_URL_MATCH });
  return tabs.find((t) => t.active) || tabs[0] || null;
}

async function onRefresh() {
  $("error").textContent = "";
  const { creds } = await chrome.storage.local.get(["creds"]);
  if (!creds || !creds.session_key) return showError("尚未擷取憑證，請先在系統內點開一次段考成績。");
  if (!creds.itemId) return showError("尚未攔到任何段考，請先在系統內點開一次段考成績。");

  const tab = await getSystemTab();
  if (!tab) return showError("找不到已開啟的校務系統分頁。\n請先開啟並登入 sschool.tp.edu.tw。");

  $("refreshBtn").disabled = true;
  $("refreshBtn").textContent = "查詢中…";
  try {
    const resp = await chrome.tabs.sendMessage(tab.id, {
      action: "queryAll",
      itemId: creds.itemId,
      stdSemeId: creds.stdSemeId,
      session_key: creds.session_key,
    });
    if (!resp) throw new Error("沒有回應，請重新整理校務系統分頁後再試。");
    if (!resp.ok) throw new Error(resp.error || "查詢失敗");
    const now = Date.now();
    await chrome.storage.local.set({
      lastScore: { rows: resp.scoreRows || [], at: now },
      lastStat: { rows: resp.statRows || [], at: now },
    });
    await refreshView();
  } catch (e) {
    showError(String((e && e.message) || e));
  } finally {
    $("refreshBtn").disabled = false;
    $("refreshBtn").textContent = "重新查詢（即時）";
  }
}

// 總排名卡片（ItemScoreStat_select：scoreT 總分、scoreV 平均、各層排名）
function renderStat(s) {
  const cell = (label, val, cls = "") =>
    `<div class="statcell ${cls}"><div class="k">${label}</div><div class="v">${val}</div></div>`;
  const rank = (ord, pnm) =>
    ord != null ? `${ord}<span class="slash">/${pnm ?? "-"}</span>` : "—";

  return `<div class="statcard">
    <div class="title">總成績</div>
    <div class="statrow">
      ${cell("總分", s.scoreT != null ? s.scoreT : "—")}
      ${cell("平均", s.scoreV != null ? Number(s.scoreV).toFixed(2) : "—", "accent")}
    </div>
    <div class="statrow">
      ${cell("班排", rank(s.orderS, s.pnmS))}
      ${cell("年級排", rank(s.orderG, s.pnmG), "hl")}
      ${cell("類組排", rank(s.orderC, s.pnmC))}
    </div>
  </div>`;
}

// 各科表格（OpenItemScoreView_select）
function renderRows(rows) {
  if (!rows || !rows.length) {
    return `<div class="subhead">各科成績查無資料（可能尚未輸入）。</div>`;
  }
  const first = rows[0];
  const header =
    `<div class="subhead">${first.stdClsId || ""}　座號 ${first.stdSeat || first.clsSeat || "-"}　共 ${rows.length} 科</div>`;

  let total = 0, count = 0;
  const body = rows
    .map((r) => {
      const has = typeof r.score === "number";
      const score = has ? r.score : "—";
      if (has) { total += r.score; count++; }
      // 班排 = orderS / pnmS；PR = scorePg2（小數百分位）。沒算出來就顯示 —
      const rank = r.orderS != null ? `${r.orderS}/${r.pnmS ?? "-"}` : "—";
      const pr = r.scorePg2 != null ? r.scorePg2 : "—";
      return `<tr>
        <td>${r.subjId ?? "-"}</td>
        <td class="score ${scoreClass(r.score)}">${score}</td>
        <td>${rank}</td>
        <td>${pr}</td>
        <td>${r.credits ?? "-"}</td>
      </tr>`;
    })
    .join("");

  const avg = count ? (total / count).toFixed(2) : "—";
  return (
    header +
    `<table>
      <thead><tr><th>科目</th><th>分數</th><th>班排</th><th>PR</th><th>學分</th></tr></thead>
      <tbody>${body}</tbody>
    </table>
    <div class="avg">各科平均（有分數科目）：<b>${avg}</b></div>`
  );
}

function scoreClass(v) {
  if (typeof v !== "number") return "";
  if (v >= 90) return "s-hi";
  if (v >= 80) return "s-mid";
  if (v >= 60) return "s-low";
  return "s-fail";
}

function showError(msg) {
  $("error").textContent = msg;
}
